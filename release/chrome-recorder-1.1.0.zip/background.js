/******/ (() => { // webpackBootstrap
/******/ 	"use strict";

;// ./src/popup/utils/diagnostics.ts
/* unused harmony import specifier */ var MAX_RECORDING_SECONDS;
/* unused harmony import specifier */ var PEAKS_PER_SECOND;
/* unused harmony import specifier */ var LIVE_LEVELS_PER_SECOND;
/* unused harmony import specifier */ var getPendingRecoverySummary;
/* unused harmony import specifier */ var getAllRecordingsMetadata;
/* unused harmony import specifier */ var getStorageUsage;
// Diagnostics for bug reports: a rolling log of recent errors and key events, plus a snapshot of the
// environment, capabilities, recording state and storage.
// Never includes audio, recording names, tab titles or page content (names often come from tab titles).

const LOG_KEY = 'diagnosticsLog';
const MAX_ENTRIES = 50;
const MAX_MESSAGE_LENGTH = 500;
function errorMessage(error) {
    const message = error instanceof Error ? `${error.name}: ${error.message}` : String(error);
    return message.slice(0, MAX_MESSAGE_LENGTH);
}
// Append to the log. Must run where chrome.storage is available (popup, export tab, background).
async function appendDiagnostic(context, message, level = 'error') {
    const result = await chrome.storage.local.get([LOG_KEY]);
    const entries = result[LOG_KEY] || [];
    entries.push({ time: new Date().toISOString(), context, message: message.slice(0, MAX_MESSAGE_LENGTH), level });
    await chrome.storage.local.set({ [LOG_KEY]: entries.slice(-MAX_ENTRIES) });
}
function record(context, message, level) {
    try {
        if (chrome.storage?.local) {
            appendDiagnostic(context, message, level).catch(() => { });
        }
        else {
            // The offscreen document has no chrome.storage; the background writes for it
            chrome.runtime.sendMessage({ action: 'logDiagnostic', context, message, level }).catch(() => { });
        }
    }
    catch {
        // Diagnostics must never break the caller
    }
}
// Log an error to the console and the diagnostics log
function logError(context, error) {
    console.error(`${context}:`, error);
    record(context, errorMessage(error), 'error');
}
// Log a notable event (recording started/saved, export finished...). Keep messages free of names.
function logEvent(context, message) {
    record(context, message, 'info');
}
// Record uncaught errors from a page
function installErrorCapture(page) {
    window.addEventListener('error', (event) => logError(`${page}: uncaught error`, event.error || event.message));
    window.addEventListener('unhandledrejection', (event) => logError(`${page}: unhandled rejection`, event.reason));
}
function formatBytes(bytes) {
    if (bytes >= 1024 * 1024 * 1024)
        return `${(bytes / (1024 * 1024 * 1024)).toFixed(2)} GB`;
    if (bytes >= 1024 * 1024)
        return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
    return `${(bytes / 1024).toFixed(1)} KB`;
}
function formatSeconds(seconds) {
    if (!(seconds >= 0))
        return 'unknown';
    const minutes = Math.floor(seconds / 60);
    if (minutes === 0)
        return `${seconds.toFixed(1)}s`;
    const rest = seconds % 60;
    return rest < 0.05 ? `${minutes}m` : `${minutes}m ${rest.toFixed(1)}s`;
}
// Run one section; a failure is reported in the section instead of aborting the report
async function section(lines, title, fill) {
    lines.push('', `[${title}]`);
    const add = (label, value) => lines.push(`${label}: ${value}`);
    try {
        await fill(add);
    }
    catch (error) {
        add('unavailable', errorMessage(error));
    }
}
async function supported(check) {
    try {
        return (await check()) ? 'yes' : 'no';
    }
    catch (error) {
        return `no (${errorMessage(error)})`;
    }
}
// Plain-text summary for pasting into a bug report
async function buildDiagnosticsReport() {
    const now = new Date();
    const lines = [
        '--- Chrome Recorder diagnostics ---',
        'Contains no audio, recording names, tab titles or page content.',
        `Generated: ${now.toISOString()} (UTC offset ${-now.getTimezoneOffset() / 60}h)`
    ];
    await section(lines, 'Extension', (add) => {
        const manifest = chrome.runtime.getManifest();
        add('Version', manifest.version);
        add('Minimum Chrome', manifest.minimum_chrome_version || 'none');
        add('Recording limit', formatSeconds(MAX_RECORDING_SECONDS));
        add('Waveform resolution', `${PEAKS_PER_SECOND}/s stored, ${LIVE_LEVELS_PER_SECOND}/s live`);
    });
    await section(lines, 'Browser and OS', async (add) => {
        add('User agent', navigator.userAgent);
        const uaData = navigator.userAgentData;
        if (uaData) {
            const details = await uaData.getHighEntropyValues(['platformVersion', 'architecture', 'bitness', 'fullVersionList', 'model']);
            const chromeVersion = (details.fullVersionList || []).find((b) => /Chrom/.test(b.brand) && !/Not/.test(b.brand));
            add('Chrome', chromeVersion ? `${chromeVersion.brand} ${chromeVersion.version}` : 'unknown');
            add('Platform', `${uaData.platform} ${details.platformVersion || ''}`.trim());
            add('Architecture', `${details.architecture || 'unknown'} ${details.bitness ? `${details.bitness}-bit` : ''}`.trim());
            if (details.model)
                add('Device model', details.model);
        }
        add('Language', navigator.language);
    });
    await section(lines, 'Device', async (add) => {
        add('Memory', navigator.deviceMemory ? `${navigator.deviceMemory} GB (approximate)` : 'unknown');
        add('CPU cores', navigator.hardwareConcurrency || 'unknown');
        add('Screen scale', window.devicePixelRatio);
        const context = new AudioContext();
        add('Audio output sample rate', `${context.sampleRate} Hz`);
        await context.close();
    });
    await section(lines, 'Capabilities', async (add) => {
        add('MediaRecorder Opus/WebM', await supported(() => MediaRecorder.isTypeSupported('audio/webm;codecs=opus')));
        add('AudioWorklet', await supported(() => typeof AudioWorkletNode !== 'undefined'));
        add('WebCodecs decode (Opus)', await supported(async () => typeof AudioDecoder !== 'undefined' && !!(await AudioDecoder.isConfigSupported({ codec: 'opus', sampleRate: 48000, numberOfChannels: 2 })).supported));
        add('WebCodecs encode (Opus)', await supported(async () => typeof AudioEncoder !== 'undefined' && !!(await AudioEncoder.isConfigSupported({ codec: 'opus', sampleRate: 48000, numberOfChannels: 2, bitrate: 128000 })).supported));
        add('Web Locks', await supported(() => !!navigator.locks));
        add('Persistent storage', await supported(async () => !!navigator.storage?.persisted && await navigator.storage.persisted()));
    });
    await section(lines, 'Recording state', async (add) => {
        const state = await chrome.runtime.sendMessage({ action: 'getRecordingState' });
        add('Recording now', state?.isRecording ? (state.isPaused ? 'yes (paused)' : 'yes') : 'no');
        if (state?.isRecording && state.startTime) {
            const pausedMs = (state.pausedTotal || 0) + (state.pausedAt ? Date.now() - state.pausedAt : 0);
            add('Recorded so far', formatSeconds((Date.now() - state.startTime - pausedMs) / 1000));
        }
        const pending = await getPendingRecoverySummary();
        add('Interrupted recordings awaiting recovery', `${pending.sessions} (${pending.chunks} chunks, ${formatBytes(pending.bytes)})`);
        add('Legacy v1.0.5 temp recording', pending.legacyTempBytes ? formatBytes(pending.legacyTempBytes) : 'none');
        const { autoSavedRecordingId, autoSavedReason } = await chrome.storage.local.get(['autoSavedRecordingId', 'autoSavedReason']);
        add('Auto-saved recording not yet opened', autoSavedRecordingId ? `yes (${autoSavedReason || 'unknown reason'})` : 'no');
    });
    await section(lines, 'Recordings and storage', async (add) => {
        const recordings = await getAllRecordingsMetadata();
        const totalSize = recordings.reduce((sum, r) => sum + (r.size || 0), 0);
        const durations = recordings.map(r => r.duration || 0);
        const formats = {};
        for (const r of recordings)
            formats[r.format || 'unknown'] = (formats[r.format || 'unknown'] || 0) + 1;
        add('Recordings', `${recordings.length} (${formatBytes(totalSize)})`);
        add('Stored formats', Object.entries(formats).map(([f, n]) => `${f}: ${n}`).join(', ') || 'none');
        add('Longest', formatSeconds(Math.max(0, ...durations)));
        add('Total length', formatSeconds(durations.reduce((a, b) => a + b, 0)));
        const { used, quota } = await getStorageUsage();
        add('Storage', `${formatBytes(used)} used of ${formatBytes(quota)}`);
    });
    await section(lines, 'Settings', async (add) => {
        const { preferences, theme } = await chrome.storage.local.get(['preferences', 'theme']);
        add('Preferences', JSON.stringify(preferences || {}));
        add('Theme', theme || 'dark');
    });
    await section(lines, 'Recent activity (oldest first)', async (add) => {
        const result = await chrome.storage.local.get([LOG_KEY]);
        const entries = result[LOG_KEY] || [];
        if (entries.length === 0) {
            add('Entries', 'none');
            return;
        }
        const errors = entries.filter(e => (e.level || 'error') === 'error').length;
        add('Entries', `${entries.length} (${errors} errors)`);
        for (const entry of entries) {
            lines.push(`  ${entry.time} ${(entry.level || 'error') === 'error' ? 'ERROR' : 'info '} [${entry.context}] ${entry.message}`);
        }
    });
    return lines.join('\n');
}

;// ./src/background/background.ts

// Background service worker: obtains the tab capture stream id and coordinates the offscreen
// document that records. Audio never passes through here — the offscreen document writes it
// straight to IndexedDB, so a service worker restart cannot lose a recording.
const DEFAULT_PREFERENCES = {
    format: 'wav',
    sampleRate: '44100',
    channelMode: 'stereo',
    bitDepth: '16',
    normalize: false,
    useTabTitle: false
};
// Recording state kept in storage so it survives service worker restarts and popup reopen
const RECORDING_STATE_KEYS = [
    'recordingStreamId',
    'recordingTabId',
    'recordingStartTime',
    'recordingSessionId',
    'recordingPausedAt',
    'recordingPausedTotal'
];
// Persist defaults so the Settings screen and the download logic always agree
chrome.runtime.onInstalled.addListener(async () => {
    const { preferences } = await chrome.storage.local.get(['preferences']);
    await chrome.storage.local.set({ preferences: { ...DEFAULT_PREFERENCES, ...(preferences || {}) } });
});
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'startCapture') {
        (async () => {
            let tabId = message.tabId || sender.tab?.id;
            if (!tabId) {
                const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
                tabId = tab?.id;
            }
            if (!tabId)
                throw new Error('No active tab found');
            const streamId = await captureTabAudio(tabId);
            return { success: true, streamId, method: 'tab' };
        })()
            .then(sendResponse)
            .catch((error) => sendResponse({ success: false, error: error.message }));
        return true; // Keep channel open for async response
    }
    if (message.action === 'startRecordingWithStream') {
        if (message.streamId) {
            startRecordingFromStreamId(message.streamId, message.details || {})
                .then(() => sendResponse({ success: true }))
                .catch((error) => sendResponse({ success: false, error: error.message }));
        }
        else {
            sendResponse({ success: false, error: 'Stream ID required' });
        }
        return true;
    }
    if (message.action === 'stopCapture' || message.action === 'clearRecording') {
        // clearRecording also saves rather than discards: an offscreen document that is still
        // around holds a real recording (e.g. after a service worker restart)
        stopAndSave(message.details || {})
            .then((recording) => sendResponse({ success: true, recording }))
            .catch((error) => {
            logError('Background: stop and save', error);
            sendResponse({ success: false, error: error.message });
        });
        return true;
    }
    if (message.action === 'pauseRecording' || message.action === 'resumeRecording') {
        setPaused(message.action === 'pauseRecording')
            .then((state) => sendResponse({ success: true, ...state }))
            .catch((error) => sendResponse({ success: false, error: error.message }));
        return true;
    }
    // Diagnostics from the offscreen document, which has no chrome.storage
    if (message.action === 'logDiagnostic') {
        appendDiagnostic(message.context || 'Recorder', message.message || '', message.level === 'info' ? 'info' : 'error').catch(() => { });
        return;
    }
    // The offscreen document stopped and saved a recording on its own (length limit, tab closed)
    if (message.action === 'recordingAutoStopped') {
        (async () => {
            const why = message.reason === 'ended' ? 'tab closed' : 'length limit';
            if (message.recording?.id) {
                // The popup may be closed; it loads this recording the next time it opens
                await chrome.storage.local.set({ autoSavedRecordingId: message.recording.id, autoSavedReason: message.reason });
                logEvent('Recording', `Auto-stopped (${why}) and saved: ${describeRecording(message.recording)}`);
            }
            else if (!message.error) {
                logEvent('Recording', `Auto-stopped (${why}): no audio captured, nothing saved`);
            }
            await chrome.offscreen.closeDocument().catch(() => { });
            await chrome.storage.local.remove(RECORDING_STATE_KEYS);
        })();
        return;
    }
    if (message.action === 'getRecordingState') {
        (async () => {
            const recording = await hasOffscreenDocument();
            const state = await chrome.storage.local.get(RECORDING_STATE_KEYS);
            sendResponse({
                success: true,
                isRecording: recording,
                hasRecording: recording,
                isPaused: recording && !!state.recordingPausedAt,
                startTime: state.recordingStartTime,
                pausedAt: state.recordingPausedAt || null,
                pausedTotal: state.recordingPausedTotal || 0,
                sessionId: state.recordingSessionId
            });
        })();
        return true;
    }
});
// Get a stream id for the tab (no picker, without muting)
function getMediaStreamId(tabId) {
    return new Promise((resolve, reject) => {
        chrome.tabCapture.getMediaStreamId({ targetTabId: tabId }, (streamId) => {
            if (chrome.runtime.lastError) {
                reject(new Error(chrome.runtime.lastError.message));
            }
            else if (!streamId) {
                reject(new Error('Failed to get media stream ID'));
            }
            else {
                resolve(streamId);
            }
        });
    });
}
// Chrome needs a moment to release a previous capture of the same tab; retry on "active stream" errors
async function captureTabAudio(tabId) {
    const maxRetries = 3;
    const retryDelay = 200;
    for (let attempt = 0;; attempt++) {
        try {
            const streamId = await getMediaStreamId(tabId);
            await chrome.storage.local.set({ recordingStreamId: streamId, recordingTabId: tabId });
            return streamId;
        }
        catch (error) {
            const errorMsg = error?.message || '';
            const isActiveStream = errorMsg.includes('active stream') || errorMsg.includes('Cannot capture');
            if (!isActiveStream || attempt >= maxRetries)
                throw error;
            console.log(`Retry ${attempt + 1}/${maxRetries} for tab capture after active stream error`);
            await new Promise(resolve => setTimeout(resolve, retryDelay * (attempt + 1)));
        }
    }
}
// Offscreen handling
let creatingOffscreenDocument = null;
async function hasOffscreenDocument() {
    const contexts = await chrome.runtime.getContexts({
        contextTypes: [chrome.runtime.ContextType.OFFSCREEN_DOCUMENT]
    });
    return contexts.length > 0;
}
async function setupOffscreenDocument(path) {
    if (await hasOffscreenDocument())
        return;
    if (creatingOffscreenDocument) {
        await creatingOffscreenDocument;
    }
    else {
        creatingOffscreenDocument = chrome.offscreen.createDocument({
            url: path,
            reasons: [chrome.offscreen.Reason.USER_MEDIA],
            justification: 'Recording from chrome.tabCapture API'
        });
        try {
            await creatingOffscreenDocument;
        }
        finally {
            creatingOffscreenDocument = null;
        }
    }
}
function sendToOffscreen(type, extra = {}) {
    return chrome.runtime.sendMessage({ type, target: 'offscreen', ...extra });
}
async function startRecordingFromStreamId(streamId, details) {
    await setupOffscreenDocument('offscreen.html');
    // Wait a bit for offscreen to be ready
    await new Promise(resolve => setTimeout(resolve, 50));
    // The session id is the start time; chunks are stored under it until the recording is saved
    const sessionId = Date.now().toString();
    const response = await sendToOffscreen('START_RECORDING', { streamId, sessionId, details });
    if (!response?.success) {
        await chrome.offscreen.closeDocument().catch(() => { });
        throw new Error(response?.error || 'Failed to start offscreen recording');
    }
    await chrome.storage.local.set({
        recordingStartTime: Number(sessionId),
        recordingSessionId: sessionId,
        recordingPausedAt: null,
        recordingPausedTotal: 0
    });
    logEvent('Recording', 'Started');
}
function describeRecording(recording) {
    if (!recording)
        return 'no audio captured';
    return `${formatSeconds(recording.duration || 0)}, ${formatBytes(recording.size || 0)}`;
}
async function stopAndSave(details) {
    if (!(await hasOffscreenDocument())) {
        await chrome.storage.local.remove(RECORDING_STATE_KEYS);
        return null;
    }
    try {
        // Resolves after the offscreen document has saved the recording to IndexedDB
        const response = await sendToOffscreen('STOP_RECORDING', { details });
        if (!response?.success) {
            throw new Error(response?.error || 'Failed to save recording');
        }
        logEvent('Recording', `Stopped and saved: ${describeRecording(response.recording)}`);
        return response.recording;
    }
    finally {
        await chrome.offscreen.closeDocument().catch(() => { });
        await chrome.storage.local.remove(RECORDING_STATE_KEYS);
    }
}
async function setPaused(pause) {
    if (!(await hasOffscreenDocument()))
        throw new Error('Not recording');
    const state = await chrome.storage.local.get(['recordingPausedAt', 'recordingPausedTotal']);
    const now = Date.now();
    if (pause && !state.recordingPausedAt) {
        await sendToOffscreen('PAUSE_RECORDING');
        await chrome.storage.local.set({ recordingPausedAt: now });
        logEvent('Recording', 'Paused');
    }
    else if (!pause && state.recordingPausedAt) {
        await sendToOffscreen('RESUME_RECORDING');
        await chrome.storage.local.set({
            recordingPausedAt: null,
            recordingPausedTotal: (state.recordingPausedTotal || 0) + (now - state.recordingPausedAt)
        });
        logEvent('Recording', `Resumed after ${formatSeconds((now - state.recordingPausedAt) / 1000)} paused`);
    }
    const updated = await chrome.storage.local.get(['recordingPausedAt', 'recordingPausedTotal']);
    return { pausedAt: updated.recordingPausedAt || null, pausedTotal: updated.recordingPausedTotal || 0 };
}

/******/ })()
;