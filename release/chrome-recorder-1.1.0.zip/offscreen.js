/******/ (() => { // webpackBootstrap
/******/ 	"use strict";

;// ./src/popup/utils/diagnostics.ts
/* unused harmony import specifier */ var MAX_RECORDING_SECONDS;
/* unused harmony import specifier */ var PEAKS_PER_SECOND;
/* unused harmony import specifier */ var LIVE_LEVELS_PER_SECOND;
/* unused harmony import specifier */ var getPendingRecoverySummary;
/* unused harmony import specifier */ var getAllRecordingsMetadata;
/* unused harmony import specifier */ var getStorageUsage;
// Diagnostics for bug reports: a rolling log of recent errors and key events, plus a snapshot of the
// environment, capabilities, recording state and storage.
// Never includes audio, recording names, tab titles or page content (names often come from tab titles).

const LOG_KEY = 'diagnosticsLog';
const MAX_ENTRIES = 50;
const MAX_MESSAGE_LENGTH = 500;
function errorMessage(error) {
    const message = error instanceof Error ? `${error.name}: ${error.message}` : String(error);
    return message.slice(0, MAX_MESSAGE_LENGTH);
}
// Append to the log. Must run where chrome.storage is available (popup, export tab, background).
async function appendDiagnostic(context, message, level = 'error') {
    const result = await chrome.storage.local.get([LOG_KEY]);
    const entries = result[LOG_KEY] || [];
    entries.push({ time: new Date().toISOString(), context, message: message.slice(0, MAX_MESSAGE_LENGTH), level });
    await chrome.storage.local.set({ [LOG_KEY]: entries.slice(-MAX_ENTRIES) });
}
function record(context, message, level) {
    try {
        if (chrome.storage?.local) {
            appendDiagnostic(context, message, level).catch(() => { });
        }
        else {
            // The offscreen document has no chrome.storage; the background writes for it
            chrome.runtime.sendMessage({ action: 'logDiagnostic', context, message, level }).catch(() => { });
        }
    }
    catch {
        // Diagnostics must never break the caller
    }
}
// Log an error to the console and the diagnostics log
function logError(context, error) {
    console.error(`${context}:`, error);
    record(context, errorMessage(error), 'error');
}
// Log a notable event (recording started/saved, export finished...). Keep messages free of names.
function logEvent(context, message) {
    record(context, message, 'info');
}
// Record uncaught errors from a page
function installErrorCapture(page) {
    window.addEventListener('error', (event) => logError(`${page}: uncaught error`, event.error || event.message));
    window.addEventListener('unhandledrejection', (event) => logError(`${page}: unhandled rejection`, event.reason));
}
function formatBytes(bytes) {
    if (bytes >= 1024 * 1024 * 1024)
        return `${(bytes / (1024 * 1024 * 1024)).toFixed(2)} GB`;
    if (bytes >= 1024 * 1024)
        return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
    return `${(bytes / 1024).toFixed(1)} KB`;
}
function formatSeconds(seconds) {
    if (!(seconds >= 0))
        return 'unknown';
    const minutes = Math.floor(seconds / 60);
    if (minutes === 0)
        return `${seconds.toFixed(1)}s`;
    const rest = seconds % 60;
    return rest < 0.05 ? `${minutes}m` : `${minutes}m ${rest.toFixed(1)}s`;
}
// Run one section; a failure is reported in the section instead of aborting the report
async function section(lines, title, fill) {
    lines.push('', `[${title}]`);
    const add = (label, value) => lines.push(`${label}: ${value}`);
    try {
        await fill(add);
    }
    catch (error) {
        add('unavailable', errorMessage(error));
    }
}
async function supported(check) {
    try {
        return (await check()) ? 'yes' : 'no';
    }
    catch (error) {
        return `no (${errorMessage(error)})`;
    }
}
// Plain-text summary for pasting into a bug report
async function buildDiagnosticsReport() {
    const now = new Date();
    const lines = [
        '--- Chrome Recorder diagnostics ---',
        'Contains no audio, recording names, tab titles or page content.',
        `Generated: ${now.toISOString()} (UTC offset ${-now.getTimezoneOffset() / 60}h)`
    ];
    await section(lines, 'Extension', (add) => {
        const manifest = chrome.runtime.getManifest();
        add('Version', manifest.version);
        add('Minimum Chrome', manifest.minimum_chrome_version || 'none');
        add('Recording limit', formatSeconds(MAX_RECORDING_SECONDS));
        add('Waveform resolution', `${PEAKS_PER_SECOND}/s stored, ${LIVE_LEVELS_PER_SECOND}/s live`);
    });
    await section(lines, 'Browser and OS', async (add) => {
        add('User agent', navigator.userAgent);
        const uaData = navigator.userAgentData;
        if (uaData) {
            const details = await uaData.getHighEntropyValues(['platformVersion', 'architecture', 'bitness', 'fullVersionList', 'model']);
            const chromeVersion = (details.fullVersionList || []).find((b) => /Chrom/.test(b.brand) && !/Not/.test(b.brand));
            add('Chrome', chromeVersion ? `${chromeVersion.brand} ${chromeVersion.version}` : 'unknown');
            add('Platform', `${uaData.platform} ${details.platformVersion || ''}`.trim());
            add('Architecture', `${details.architecture || 'unknown'} ${details.bitness ? `${details.bitness}-bit` : ''}`.trim());
            if (details.model)
                add('Device model', details.model);
        }
        add('Language', navigator.language);
    });
    await section(lines, 'Device', async (add) => {
        add('Memory', navigator.deviceMemory ? `${navigator.deviceMemory} GB (approximate)` : 'unknown');
        add('CPU cores', navigator.hardwareConcurrency || 'unknown');
        add('Screen scale', window.devicePixelRatio);
        const context = new AudioContext();
        add('Audio output sample rate', `${context.sampleRate} Hz`);
        await context.close();
    });
    await section(lines, 'Capabilities', async (add) => {
        add('MediaRecorder Opus/WebM', await supported(() => MediaRecorder.isTypeSupported('audio/webm;codecs=opus')));
        add('AudioWorklet', await supported(() => typeof AudioWorkletNode !== 'undefined'));
        add('WebCodecs decode (Opus)', await supported(async () => typeof AudioDecoder !== 'undefined' && !!(await AudioDecoder.isConfigSupported({ codec: 'opus', sampleRate: 48000, numberOfChannels: 2 })).supported));
        add('WebCodecs encode (Opus)', await supported(async () => typeof AudioEncoder !== 'undefined' && !!(await AudioEncoder.isConfigSupported({ codec: 'opus', sampleRate: 48000, numberOfChannels: 2, bitrate: 128000 })).supported));
        add('Web Locks', await supported(() => !!navigator.locks));
        add('Persistent storage', await supported(async () => !!navigator.storage?.persisted && await navigator.storage.persisted()));
    });
    await section(lines, 'Recording state', async (add) => {
        const state = await chrome.runtime.sendMessage({ action: 'getRecordingState' });
        add('Recording now', state?.isRecording ? (state.isPaused ? 'yes (paused)' : 'yes') : 'no');
        if (state?.isRecording && state.startTime) {
            const pausedMs = (state.pausedTotal || 0) + (state.pausedAt ? Date.now() - state.pausedAt : 0);
            add('Recorded so far', formatSeconds((Date.now() - state.startTime - pausedMs) / 1000));
        }
        const pending = await getPendingRecoverySummary();
        add('Interrupted recordings awaiting recovery', `${pending.sessions} (${pending.chunks} chunks, ${formatBytes(pending.bytes)})`);
        add('Legacy v1.0.5 temp recording', pending.legacyTempBytes ? formatBytes(pending.legacyTempBytes) : 'none');
        const { autoSavedRecordingId, autoSavedReason } = await chrome.storage.local.get(['autoSavedRecordingId', 'autoSavedReason']);
        add('Auto-saved recording not yet opened', autoSavedRecordingId ? `yes (${autoSavedReason || 'unknown reason'})` : 'no');
    });
    await section(lines, 'Recordings and storage', async (add) => {
        const recordings = await getAllRecordingsMetadata();
        const totalSize = recordings.reduce((sum, r) => sum + (r.size || 0), 0);
        const durations = recordings.map(r => r.duration || 0);
        const formats = {};
        for (const r of recordings)
            formats[r.format || 'unknown'] = (formats[r.format || 'unknown'] || 0) + 1;
        add('Recordings', `${recordings.length} (${formatBytes(totalSize)})`);
        add('Stored formats', Object.entries(formats).map(([f, n]) => `${f}: ${n}`).join(', ') || 'none');
        add('Longest', formatSeconds(Math.max(0, ...durations)));
        add('Total length', formatSeconds(durations.reduce((a, b) => a + b, 0)));
        const { used, quota } = await getStorageUsage();
        add('Storage', `${formatBytes(used)} used of ${formatBytes(quota)}`);
    });
    await section(lines, 'Settings', async (add) => {
        const { preferences, theme } = await chrome.storage.local.get(['preferences', 'theme']);
        add('Preferences', JSON.stringify(preferences || {}));
        add('Theme', theme || 'dark');
    });
    await section(lines, 'Recent activity (oldest first)', async (add) => {
        const result = await chrome.storage.local.get([LOG_KEY]);
        const entries = result[LOG_KEY] || [];
        if (entries.length === 0) {
            add('Entries', 'none');
            return;
        }
        const errors = entries.filter(e => (e.level || 'error') === 'error').length;
        add('Entries', `${entries.length} (${errors} errors)`);
        for (const entry of entries) {
            lines.push(`  ${entry.time} ${(entry.level || 'error') === 'error' ? 'ERROR' : 'info '} [${entry.context}] ${entry.message}`);
        }
    });
    return lines.join('\n');
}

;// ./src/popup/utils/storageManager.ts
// Storage Manager - IndexedDB storage shared by the popup, background and offscreen document.
//
// Stores:
// - recordings: full records (metadata + audio Blob + waveform peaks)
// - metadata:   metadata only, so listing recordings never loads audio into memory
// - chunks:     in-progress recording chunks, written by the offscreen document every second
//               so an interrupted recording can be recovered
// - temp_store: legacy (v1.0.5 and earlier) hand-off between background and popup
// Stored waveform resolution. Higher values give more detail when zoomed in (100/s is about
// 720 KB per hour of recording). Each chunk records its rate, so changing this is safe.
const storageManager_PEAKS_PER_SECOND = 100;
const LEGACY_PEAKS_PER_SECOND = 20;
// Live waveform levels while recording (display only, not stored)
const storageManager_LIVE_LEVELS_PER_SECOND = 60;
// Recordings stop and save automatically at this length (paused time doesn't count)
const storageManager_MAX_RECORDING_SECONDS = 60 * 60;
const DB_NAME = 'AudioRecorderDB';
const DB_VERSION = 3;
const STORE_NAME = 'recordings';
const METADATA_STORE_NAME = 'metadata';
const CHUNK_STORE_NAME = 'chunks';
const TEMP_STORE_NAME = 'temp_store';
const LEGACY_TEMP_BLOB_KEY = 'temp_recording_blob';
let dbPromise = null;
function toMetadata(record) {
    const { id, name, timestamp, duration, format, channelMode, mimeType } = record;
    const size = record.size ?? record.audio?.size ?? record.audioData?.byteLength;
    return { id, name, timestamp, duration, format, channelMode, size, mimeType };
}
function requestToPromise(request) {
    return new Promise((resolve, reject) => {
        request.onsuccess = () => resolve(request.result);
        request.onerror = () => reject(request.error);
    });
}
function transactionDone(transaction) {
    return new Promise((resolve, reject) => {
        transaction.oncomplete = () => resolve();
        transaction.onerror = () => reject(transaction.error);
        transaction.onabort = () => reject(transaction.error || new Error('Transaction aborted'));
    });
}
// Initialize IndexedDB
async function openDB() {
    if (dbPromise)
        return dbPromise;
    dbPromise = new Promise((resolve, reject) => {
        const request = indexedDB.open(DB_NAME, DB_VERSION);
        request.onerror = () => {
            dbPromise = null;
            reject(request.error);
        };
        request.onsuccess = () => {
            const db = request.result;
            db.onversionchange = () => {
                db.close();
                dbPromise = null;
            };
            resolve(db);
        };
        request.onupgradeneeded = (event) => {
            const db = event.target.result;
            const transaction = event.target.transaction;
            if (!db.objectStoreNames.contains(STORE_NAME)) {
                const objectStore = db.createObjectStore(STORE_NAME, { keyPath: 'id' });
                objectStore.createIndex('timestamp', 'timestamp', { unique: false });
            }
            if (!db.objectStoreNames.contains(TEMP_STORE_NAME)) {
                db.createObjectStore(TEMP_STORE_NAME);
            }
            if (!db.objectStoreNames.contains(CHUNK_STORE_NAME)) {
                db.createObjectStore(CHUNK_STORE_NAME, { keyPath: ['sessionId', 'seq'] });
            }
            if (!db.objectStoreNames.contains(METADATA_STORE_NAME)) {
                const metadataStore = db.createObjectStore(METADATA_STORE_NAME, { keyPath: 'id' });
                // Backfill metadata for recordings saved by earlier versions
                transaction.objectStore(STORE_NAME).openCursor().onsuccess = (e) => {
                    const cursor = e.target.result;
                    if (cursor) {
                        metadataStore.put(toMetadata(cursor.value));
                        cursor.continue();
                    }
                };
            }
        };
    });
    return dbPromise;
}
// Get temporary data
async function getTempData(key) {
    const db = await openDB();
    const transaction = db.transaction([TEMP_STORE_NAME], 'readonly');
    return requestToPromise(transaction.objectStore(TEMP_STORE_NAME).get(key));
}
// Delete temporary data
async function deleteTempData(key) {
    const db = await openDB();
    const transaction = db.transaction([TEMP_STORE_NAME], 'readwrite');
    transaction.objectStore(TEMP_STORE_NAME).delete(key);
    return transactionDone(transaction);
}
// Save recording (audio, peaks and metadata) to IndexedDB
async function saveRecording(metadata, audio, peaks) {
    const db = await openDB();
    const fullMetadata = {
        ...metadata,
        size: audio.size,
        mimeType: metadata.mimeType || audio.type || undefined
    };
    const transaction = db.transaction([STORE_NAME, METADATA_STORE_NAME], 'readwrite');
    transaction.objectStore(STORE_NAME).put({ ...fullMetadata, audio, peaks });
    transaction.objectStore(METADATA_STORE_NAME).put(fullMetadata);
    await transactionDone(transaction);
    return fullMetadata;
}
// Get recording from IndexedDB
async function getRecording(id) {
    const db = await openDB();
    const transaction = db.transaction([STORE_NAME], 'readonly');
    const result = await requestToPromise(transaction.objectStore(STORE_NAME).get(id));
    if (!result)
        return null;
    const metadata = toMetadata(result);
    let audio;
    if (result.audio instanceof Blob) {
        audio = result.audio;
    }
    else {
        // Recordings saved by v1.0.5 and earlier hold an ArrayBuffer (WAV since v1.0.0)
        const legacyType = result.format === 'wav' ? 'audio/wav' : 'audio/webm';
        audio = new Blob([result.audioData], { type: legacyType });
    }
    return { metadata, audio, peaks: result.peaks };
}
// Get all recording metadata (without audio data for list view)
async function storageManager_getAllRecordingsMetadata() {
    const db = await openDB();
    const transaction = db.transaction([METADATA_STORE_NAME], 'readonly');
    const recordings = await requestToPromise(transaction.objectStore(METADATA_STORE_NAME).getAll());
    // Sort by timestamp descending (most recent first)
    recordings.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
    return recordings;
}
// Delete recording from IndexedDB
async function deleteRecording(id) {
    const db = await openDB();
    const transaction = db.transaction([STORE_NAME, METADATA_STORE_NAME], 'readwrite');
    transaction.objectStore(STORE_NAME).delete(id);
    transaction.objectStore(METADATA_STORE_NAME).delete(id);
    return transactionDone(transaction);
}
// Get storage usage estimate
async function storageManager_getStorageUsage() {
    if ('storage' in navigator && 'estimate' in navigator.storage) {
        const estimate = await navigator.storage.estimate();
        return {
            used: estimate.usage || 0,
            quota: estimate.quota || 0
        };
    }
    return { used: 0, quota: 0 };
}
// Clear all recordings
async function clearAllRecordings() {
    const db = await openDB();
    const transaction = db.transaction([STORE_NAME, METADATA_STORE_NAME], 'readwrite');
    transaction.objectStore(STORE_NAME).clear();
    transaction.objectStore(METADATA_STORE_NAME).clear();
    return transactionDone(transaction);
}
// Update recording name
async function updateRecordingName(id, newName) {
    const db = await openDB();
    const transaction = db.transaction([STORE_NAME, METADATA_STORE_NAME], 'readwrite');
    const store = transaction.objectStore(STORE_NAME);
    const metadataStore = transaction.objectStore(METADATA_STORE_NAME);
    const recording = await requestToPromise(store.get(id));
    if (!recording) {
        transaction.abort();
        throw new Error('Recording not found');
    }
    recording.name = newName;
    store.put(recording);
    metadataStore.put(toMetadata(recording));
    return transactionDone(transaction);
}
// Store waveform peaks computed after the fact (older or recovered recordings)
async function updateRecordingPeaks(id, peaks) {
    const db = await openDB();
    const transaction = db.transaction([STORE_NAME, METADATA_STORE_NAME], 'readwrite');
    const store = transaction.objectStore(STORE_NAME);
    const recording = await requestToPromise(store.get(id));
    if (!recording) {
        transaction.abort();
        return;
    }
    recording.peaks = peaks;
    if (!recording.duration)
        recording.duration = peaks.max.length / peaks.rate;
    store.put(recording);
    transaction.objectStore(METADATA_STORE_NAME).put(toMetadata(recording));
    return transactionDone(transaction);
}
// --- In-progress recording chunks ---
// Append one chunk of an in-progress recording
async function appendRecordingChunk(chunk) {
    const db = await openDB();
    const transaction = db.transaction([CHUNK_STORE_NAME], 'readwrite');
    transaction.objectStore(CHUNK_STORE_NAME).put(chunk);
    return transactionDone(transaction);
}
function sessionRange(sessionId) {
    return IDBKeyRange.bound([sessionId, -Infinity], [sessionId, Infinity]);
}
// Assemble the chunks of a recording session into a saved recording, then delete the chunks.
// Returns null when the session has no audio.
async function finalizeRecordingSession(sessionId, details) {
    const db = await openDB();
    const readTransaction = db.transaction([CHUNK_STORE_NAME], 'readonly');
    // Keys are [sessionId, seq], so getAll returns the chunks in recording order
    const chunks = await requestToPromise(readTransaction.objectStore(CHUNK_STORE_NAME).getAll(sessionRange(sessionId)));
    const audioParts = chunks.map(c => c.audio).filter(a => a && a.size > 0);
    let metadata = null;
    if (audioParts.length > 0) {
        const audio = new Blob(audioParts, { type: 'audio/webm' });
        const peakCount = chunks.reduce((sum, c) => sum + (c.peakMax?.length || 0), 0);
        const max = new Uint8Array(peakCount);
        const avg = new Uint8Array(peakCount);
        let offset = 0;
        for (const chunk of chunks) {
            if (!chunk.peakMax)
                continue;
            max.set(chunk.peakMax, offset);
            avg.set(chunk.peakAvg, offset);
            offset += chunk.peakMax.length;
        }
        const peakRate = chunks[0]?.peakRate || LEGACY_PEAKS_PER_SECOND;
        const duration = peakCount > 0 ? peakCount / peakRate : (details.fallbackDuration || 0);
        // Session ids are the recording start time in ms
        const startedAt = Number(sessionId);
        metadata = await saveRecording({
            id: sessionId,
            name: details.name,
            timestamp: details.timestamp || new Date(isFinite(startedAt) ? startedAt : Date.now()).toISOString(),
            duration,
            format: 'webm',
            channelMode: details.channelMode || 'stereo',
            mimeType: 'audio/webm'
        }, audio, peakCount > 0 ? { rate: peakRate, max, avg } : undefined);
    }
    const deleteTransaction = db.transaction([CHUNK_STORE_NAME], 'readwrite');
    deleteTransaction.objectStore(CHUNK_STORE_NAME).delete(sessionRange(sessionId));
    await transactionDone(deleteTransaction);
    return metadata;
}
// List session ids that still have chunks in storage
async function listChunkSessions() {
    const db = await openDB();
    const transaction = db.transaction([CHUNK_STORE_NAME], 'readonly');
    const store = transaction.objectStore(CHUNK_STORE_NAME);
    return new Promise((resolve, reject) => {
        const sessions = [];
        const request = store.openKeyCursor();
        request.onsuccess = () => {
            const cursor = request.result;
            if (!cursor) {
                resolve(sessions);
                return;
            }
            const sessionId = cursor.key[0];
            sessions.push(sessionId);
            cursor.continue([sessionId, Infinity]);
        };
        request.onerror = () => reject(request.error);
    });
}
// What is waiting to be recovered, for diagnostics: interrupted sessions in the chunk store and the
// legacy (v1.0.5) temp blob. Reads blob sizes only, not audio data.
async function storageManager_getPendingRecoverySummary() {
    const db = await openDB();
    const transaction = db.transaction([CHUNK_STORE_NAME, TEMP_STORE_NAME], 'readonly');
    const chunks = await requestToPromise(transaction.objectStore(CHUNK_STORE_NAME).getAll());
    const legacy = await requestToPromise(transaction.objectStore(TEMP_STORE_NAME).get(LEGACY_TEMP_BLOB_KEY));
    return {
        sessions: new Set(chunks.map(c => c.sessionId)).size,
        chunks: chunks.length,
        bytes: chunks.reduce((sum, c) => sum + (c.audio?.size || 0), 0),
        legacyTempBytes: legacy instanceof Blob ? legacy.size : 0
    };
}
// Save recordings that were interrupted (browser crash, extension update, popup closed during save)
// as "recovered" recordings. Call only when no recording is in progress, excluding the active session.
async function recoverInterruptedRecordings(activeSessionId) {
    const recovered = [];
    for (const sessionId of await listChunkSessions()) {
        if (sessionId === activeSessionId)
            continue;
        try {
            const startedAt = Number(sessionId);
            const label = new Date(isFinite(startedAt) ? startedAt : Date.now()).toLocaleString();
            const metadata = await finalizeRecordingSession(sessionId, { name: `recovered recording ${label}` });
            if (metadata)
                recovered.push(metadata);
        }
        catch (error) {
            console.error(`Failed to recover recording session ${sessionId}:`, error);
        }
    }
    // v1.0.5 and earlier stored the finished recording here before the popup converted it
    try {
        const legacyBlob = await getTempData(LEGACY_TEMP_BLOB_KEY);
        if (legacyBlob instanceof Blob && legacyBlob.size > 0) {
            const id = Date.now().toString();
            recovered.push(await saveRecording({
                id,
                name: `recovered recording ${new Date().toLocaleString()}`,
                timestamp: new Date().toISOString(),
                duration: 0,
                format: 'webm',
                channelMode: 'stereo',
                mimeType: 'audio/webm'
            }, new Blob([legacyBlob], { type: 'audio/webm' })));
        }
        if (legacyBlob)
            await deleteTempData(LEGACY_TEMP_BLOB_KEY);
    }
    catch (error) {
        console.error('Failed to recover legacy temp recording:', error);
    }
    return recovered;
}
// Migrate recordings from chrome.storage.local to IndexedDB
async function migrateFromChromeStorage() {
    const result = await chrome.storage.local.get(['savedRecordings']);
    const savedRecordings = result.savedRecordings || [];
    if (savedRecordings.length === 0)
        return 0;
    let migratedCount = 0;
    for (const recording of savedRecordings) {
        try {
            const audio = new Blob([new Uint8Array(recording.audioData)], { type: 'audio/webm' });
            await saveRecording({
                id: recording.id,
                name: recording.name,
                timestamp: recording.timestamp,
                duration: recording.duration,
                format: recording.format,
                channelMode: recording.channelMode
            }, audio);
            migratedCount++;
        }
        catch (error) {
            console.error(`Failed to migrate recording ${recording.id}:`, error);
        }
    }
    // Clear chrome.storage.local recordings after successful migration
    if (migratedCount > 0) {
        await chrome.storage.local.remove(['savedRecordings']);
    }
    return migratedCount;
}

;// ./src/offscreen/offscreen.ts


// Offscreen document: owns the MediaRecorder and persists audio to IndexedDB every second,
// so a recording survives a service worker restart, popup crash or browser crash.
const CHUNK_INTERVAL_MS = 1000;
const AUDIO_BITS_PER_SECOND = 128000;
// Live waveform: recent loudness levels (LIVE_LEVELS_PER_SECOND), streamed to the popup
const LIVE_LEVELS_SENT = storageManager_LIVE_LEVELS_PER_SECOND * 6; // enough history to fill the view when the popup opens
const LIVE_LEVELS_KEPT = LIVE_LEVELS_SENT * 2;
const LIVE_WAVEFORM_INTERVAL_MS = 16; // ~60 FPS
let session = null;
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.target !== 'offscreen')
        return;
    if (message.type === 'START_RECORDING') {
        startRecording(message.streamId, message.sessionId, message.details || {})
            .then(() => sendResponse({ success: true }))
            .catch((err) => sendResponse({ success: false, error: err.message }));
        return true;
    }
    if (message.type === 'STOP_RECORDING') {
        stopRecording(message.details || {})
            .then((recording) => sendResponse({ success: true, recording }))
            .catch((err) => sendResponse({ success: false, error: err?.message || String(err) }));
        return true;
    }
    // The popup asks when it reopens during a recording, to show the recording's own name and start
    if (message.type === 'GET_SESSION') {
        sendResponse(session
            ? { success: true, name: session.details.name, startedAt: session.startedAt }
            : { success: false });
        return;
    }
    if (message.type === 'PAUSE_RECORDING' || message.type === 'RESUME_RECORDING') {
        const pause = message.type === 'PAUSE_RECORDING';
        if (session && !session.stopping) {
            if (pause && session.recorder.state === 'recording')
                session.recorder.pause();
            if (!pause && session.recorder.state === 'paused')
                session.recorder.resume();
            session.peakNode?.port.postMessage(pause ? 'pause' : 'resume');
            updateFallbackLimit(session, pause);
        }
        sendResponse({ success: !!session });
    }
});
function toByte(value) {
    return Math.min(255, Math.round(value * 255));
}
// Stop and save without the popup — at the length limit, or when the captured tab closes —
// then tell the background and popup
async function autoStop(current, reason) {
    if (current.stopping)
        return;
    try {
        const recording = await stopRecording(current.details);
        chrome.runtime.sendMessage({ action: 'recordingAutoStopped', reason, recording }).catch(() => { });
    }
    catch (error) {
        logError(`Recorder: save after auto-stop (${reason})`, error);
        chrome.runtime.sendMessage({ action: 'recordingAutoStopped', reason, error: error?.message || String(error) }).catch(() => { });
    }
}
function pushLevel(current, max, avg) {
    current.levels.push(max);
    current.avgLevels.push(avg);
    if (max > current.loudestLevel)
        current.loudestLevel = max;
    current.levelCount++;
    if (current.levels.length > LIVE_LEVELS_KEPT) {
        current.levels.splice(0, current.levels.length - LIVE_LEVELS_SENT);
        current.avgLevels.splice(0, current.avgLevels.length - LIVE_LEVELS_SENT);
    }
}
// The popup opens a port while it is showing a recording in progress. Each message also carries
// the recorded time (the same clock as the length limit) so the popup's clock and countdown
// match it, including after the computer sleeps.
chrome.runtime.onConnect.addListener((port) => {
    if (port.name !== 'waveform')
        return;
    const samples = new Float32Array(2048);
    let lastSentCount = -1;
    let lastSentPaused = null;
    const interval = window.setInterval(() => {
        if (!session || session.recorder.state === 'inactive')
            return;
        const paused = session.recorder.state === 'paused';
        // Without the peak meter, measure the level here from the analyser instead
        if (!session.peakNode && !paused) {
            session.analyser.getFloatTimeDomainData(samples);
            let max = 0;
            let sum = 0;
            for (let i = 0; i < samples.length; i++) {
                const abs = Math.abs(samples[i]);
                max = Math.max(max, abs);
                sum += abs;
            }
            pushLevel(session, toByte(max), toByte(sum / samples.length));
        }
        // Send when there is new audio, or when the recording is paused or resumed
        if (session.levelCount === lastSentCount && paused === lastSentPaused)
            return;
        // History on the first send, then only the levels produced since
        const fresh = lastSentCount < 0 ? LIVE_LEVELS_SENT : session.levelCount - lastSentCount;
        lastSentCount = session.levelCount;
        lastSentPaused = paused;
        const count = Math.min(fresh, LIVE_LEVELS_SENT);
        port.postMessage({
            // slice(-0) would return everything, so send nothing explicitly when there is no new audio
            levels: count > 0 ? session.levels.slice(-count) : [],
            avgLevels: count > 0 ? session.avgLevels.slice(-count) : [],
            loudest: session.loudestLevel,
            total: session.levelCount,
            seconds: recordedSeconds(session),
            paused
        });
    }, LIVE_WAVEFORM_INTERVAL_MS);
    port.onDisconnect.addListener(() => clearInterval(interval));
});
// Seconds of audio recorded so far, excluding pauses
function recordedSeconds(current) {
    if (current.peakNode)
        return current.peakCount / storageManager_PEAKS_PER_SECOND;
    const running = current.resumedAt !== null ? Date.now() - current.resumedAt : 0;
    return (current.activeMs + running) / 1000;
}
function updateFallbackLimit(current, pause) {
    if (current.peakNode)
        return;
    const now = Date.now();
    if (pause && current.resumedAt !== null) {
        current.activeMs += now - current.resumedAt;
        current.resumedAt = null;
        if (current.limitTimer)
            clearTimeout(current.limitTimer);
        current.limitTimer = null;
    }
    else if (!pause && current.resumedAt === null) {
        current.resumedAt = now;
        const remainingMs = Math.max(0, storageManager_MAX_RECORDING_SECONDS * 1000 - current.activeMs);
        current.limitTimer = window.setTimeout(() => autoStop(current, 'limit'), remainingMs);
    }
}
async function startRecording(streamId, sessionId, details) {
    if (session) {
        throw new Error('Called startRecording while already recording');
    }
    const media = await navigator.mediaDevices.getUserMedia({
        audio: {
            mandatory: {
                chromeMediaSource: 'tab',
                chromeMediaSourceId: streamId
            }
        },
        video: false
    });
    // Continue to play the captured audio to the user.
    const audioCtx = new AudioContext();
    const source = audioCtx.createMediaStreamSource(media);
    source.connect(audioCtx.destination);
    const analyser = audioCtx.createAnalyser();
    analyser.fftSize = 2048;
    analyser.smoothingTimeConstant = 0.8;
    source.connect(analyser);
    const pendingMax = [];
    const pendingAvg = [];
    // Waveform peaks are measured on the audio thread so they stay sample-accurate for long recordings
    let peakNode = null;
    try {
        await audioCtx.audioWorklet.addModule(chrome.runtime.getURL('peak-worklet.js'));
        peakNode = new AudioWorkletNode(audioCtx, 'peak-meter', {
            numberOfInputs: 1,
            numberOfOutputs: 1,
            processorOptions: {
                windowSize: Math.round(audioCtx.sampleRate / storageManager_PEAKS_PER_SECOND),
                liveWindowSize: Math.round(audioCtx.sampleRate / storageManager_LIVE_LEVELS_PER_SECOND)
            }
        });
        source.connect(peakNode);
        // Output is silent; connecting it keeps the node processing
        peakNode.connect(audioCtx.destination);
    }
    catch (error) {
        logError('Recorder: peak meter unavailable, waveform will be computed after recording', error);
    }
    const recorder = new MediaRecorder(media, {
        mimeType: 'audio/webm;codecs=opus',
        audioBitsPerSecond: AUDIO_BITS_PER_SECOND
    });
    const current = {
        id: sessionId,
        seq: 0,
        startedAt: Date.now(),
        recorder,
        media,
        audioCtx,
        peakNode,
        pendingMax,
        pendingAvg,
        writeChain: Promise.resolve(),
        writeError: null,
        analyser,
        details,
        peakCount: 0,
        levels: [],
        avgLevels: [],
        loudestLevel: 0,
        levelCount: 0,
        stopping: null,
        limitTimer: null,
        activeMs: 0,
        resumedAt: null
    };
    if (peakNode) {
        // Each peak window is 1/PEAKS_PER_SECOND s of recorded audio, so the count is an exact
        // clock that excludes paused time
        const maxPeaks = storageManager_MAX_RECORDING_SECONDS * storageManager_PEAKS_PER_SECOND;
        peakNode.port.onmessage = (event) => {
            const max = toByte(event.data.max);
            const avg = toByte(event.data.avg);
            if (event.data.live) {
                pushLevel(current, max, avg);
                return;
            }
            pendingMax.push(max);
            pendingAvg.push(avg);
            if (++current.peakCount >= maxPeaks)
                autoStop(current, 'limit');
        };
    }
    else {
        updateFallbackLimit(current, false);
    }
    // The stream ends when the captured tab is closed (or capture is otherwise revoked)
    media.getAudioTracks().forEach((track) => {
        track.addEventListener('ended', () => autoStop(current, 'ended'));
    });
    // Chunks are written in order through a single promise chain
    recorder.ondataavailable = (event) => {
        const chunk = {
            sessionId: current.id,
            seq: current.seq++,
            audio: event.data,
            peakMax: Uint8Array.from(current.pendingMax.splice(0)),
            peakAvg: Uint8Array.from(current.pendingAvg.splice(0)),
            peakRate: storageManager_PEAKS_PER_SECOND
        };
        current.writeChain = current.writeChain
            .then(() => appendRecordingChunk(chunk))
            .catch((error) => {
            logError('Recorder: persist chunk', error);
            current.writeError = error;
        });
    };
    session = current;
    recorder.start(CHUNK_INTERVAL_MS);
}
// Safe to call more than once (manual stop racing the length limit); later calls share the result
function stopRecording(details) {
    const current = session;
    if (!current)
        return Promise.resolve(null);
    if (!current.stopping)
        current.stopping = finishRecording(current, details);
    return current.stopping;
}
async function finishRecording(current, details) {
    if (current.limitTimer)
        clearTimeout(current.limitTimer);
    // dataavailable (the final chunk) fires before stop
    if (current.recorder.state !== 'inactive') {
        await new Promise((resolve) => {
            current.recorder.onstop = () => resolve();
            current.recorder.stop();
        });
    }
    await current.writeChain;
    current.media.getTracks().forEach((t) => t.stop());
    current.audioCtx.close().catch(() => { });
    if (current.writeError) {
        logError('Recorder', 'Some chunks failed to save; saving what was stored');
    }
    try {
        return await finalizeRecordingSession(current.id, {
            name: details.name || current.details.name || `recording ${new Date(current.startedAt).toLocaleString()}`,
            channelMode: details.channelMode || current.details.channelMode,
            timestamp: new Date(current.startedAt).toISOString(),
            fallbackDuration: recordedSeconds(current)
        });
    }
    finally {
        if (session === current)
            session = null;
    }
}

/******/ })()
;