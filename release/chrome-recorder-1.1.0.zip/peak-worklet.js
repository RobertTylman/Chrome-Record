/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
// AudioWorklet that measures waveform peaks while recording.
// Posts { max, avg } (absolute amplitude, 0-1) per window of `windowSize` frames for the saved
// waveform, and { live: true, max, avg } per shorter `liveWindowSize` window for the live view.
class Window {
    constructor() {
        this.count = 0;
        this.max = 0;
        this.sum = 0;
    }
    add(sample, size) {
        if (sample > this.max)
            this.max = sample;
        this.sum += sample;
        if (++this.count < size)
            return null;
        const result = { max: this.max, avg: this.sum / this.count };
        this.count = 0;
        this.max = 0;
        this.sum = 0;
        return result;
    }
}
class PeakMeterProcessor extends AudioWorkletProcessor {
    constructor(options) {
        super(options);
        this.stored = new Window();
        this.live = new Window();
        this.paused = false;
        this.windowSize = options.processorOptions.windowSize;
        this.liveWindowSize = options.processorOptions.liveWindowSize || 0;
        this.port.onmessage = (event) => {
            if (event.data === 'pause')
                this.paused = true;
            if (event.data === 'resume')
                this.paused = false;
        };
    }
    process(inputs) {
        if (this.paused)
            return true;
        const input = inputs[0];
        // A disconnected or silent input still advances time so peaks stay aligned with the recording
        const frames = input && input.length > 0 ? input[0].length : 128;
        for (let i = 0; i < frames; i++) {
            let sample = 0;
            if (input) {
                for (let c = 0; c < input.length; c++) {
                    const abs = Math.abs(input[c][i]);
                    if (abs > sample)
                        sample = abs;
                }
            }
            const stored = this.stored.add(sample, this.windowSize);
            if (stored)
                this.port.postMessage(stored);
            if (this.liveWindowSize) {
                const live = this.live.add(sample, this.liveWindowSize);
                if (live)
                    this.port.postMessage({ live: true, ...live });
            }
        }
        return true;
    }
}
registerProcessor('peak-meter', PeakMeterProcessor);


/******/ })()
;